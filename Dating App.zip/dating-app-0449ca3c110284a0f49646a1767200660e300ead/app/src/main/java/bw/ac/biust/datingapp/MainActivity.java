package bw.ac.biust.datingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuth.AuthStateListener;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.lorentzos.flingswipe.SwipeFlingAdapterView;
import com.lorentzos.flingswipe.SwipeFlingAdapterView.OnItemClickListener;
import com.lorentzos.flingswipe.SwipeFlingAdapterView.onFlingListener;
import java.util.ArrayList;
import java.util.List;

import com.lorentzos.flingswipe.SwipeFlingAdapterView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {



    private arrayAdapter arrayAdapter;
    private cards[] cards_data;
    private String currentUid;
    private AuthStateListener firebaseAuthStateListener;
    private int i;
    ListView listView;
    private FirebaseAuth mAuth;
    private String oppositeUserSex;
    List<cards> rowItems;
    private String userSex;
    private DatabaseReference usersDb;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
       final String oppositeUserSex="";
         String userSex;

        mAuth = FirebaseAuth.getInstance();

        usersDb = FirebaseDatabase.getInstance().getReference().child("Users");
        FirebaseAuth instance = FirebaseAuth.getInstance();

        currentUid = instance.getCurrentUser().getUid();


        checkUserSex();
        rowItems = new ArrayList();
        arrayAdapter = new arrayAdapter(this, R.layout.item, this.rowItems);
        SwipeFlingAdapterView flingContainer = (SwipeFlingAdapterView) findViewById(R.id.frame);


        flingContainer.setAdapter(arrayAdapter);
        flingContainer.setFlingListener(new SwipeFlingAdapterView.onFlingListener() {
            @Override
            public void removeFirstObjectInAdapter() {
                // this is the simplest way to delete an object from the Adapter (/AdapterView)
                Log.d("LIST", "removed object!");
              rowItems.remove(0);
               arrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onLeftCardExit(Object dataObject) {
               // cards obj = (cards) dataObject;
               // String userId= obj.getUserId();
               //usersDb.child(oppositeUserSex).child(userId).child("connection").child("nope").child(currentUid).setValue(true);
               MainActivity.this.usersDb.child(MainActivity.this.oppositeUserSex).child(((cards) dataObject).getUserId()).child("connection").child("nope").child(MainActivity.this.currentUid).setValue(Boolean.valueOf(true));
                Toast.makeText(MainActivity.this, "LEFT", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onRightCardExit(Object dataObject) {

               cards obj = (cards) dataObject;
               String userId= obj.getUserId();
                //usersDb.child(oppositeUserSex).child(userId).child("connection").child("yep").child(currentUid).setValue(true);
                MainActivity.this.usersDb.child(MainActivity.this.oppositeUserSex).child(((cards) dataObject).getUserId()).child("connection").child("yep").child(MainActivity.this.currentUid).setValue(Boolean.valueOf(true));
                isConnectionMatch(userId);

                Toast.makeText(MainActivity.this, "Right!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdapterAboutToEmpty(int itemsInAdapter) {
                // Ask for more data here

            }

            @Override
            public void onScroll(float scrollProgressPercent) {

            }
        });


        // Optionally add an OnItemClickListener
        flingContainer.setOnItemClickListener(new SwipeFlingAdapterView.OnItemClickListener() {
            @Override
            public void onItemClicked(int itemPosition, Object dataObject) {
                Toast.makeText(MainActivity.this, "Clicked!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void isConnectionMatch(String userId) {
        DatabaseReference currentUserConnectionDb = usersDb.child(userSex).child(currentUid).child("connection").child("yep").child(userId);
        currentUserConnectionDb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange( DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    Toast.makeText(MainActivity.this,"new Connection", Toast.LENGTH_LONG).show();
                    usersDb.child(oppositeUserSex).child(dataSnapshot.getKey()).child("connection").child("matches").child(currentUid).setValue(true);
                    usersDb.child(userSex).child(currentUid).child("connection").child("matches").child(dataSnapshot.getKey()).setValue(true);

                }

            }

            @Override
            public void onCancelled( DatabaseError databaseError) {

            }
        });


    }




    public void checkUserSex() {
            final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            String str = "Users";

            DatabaseReference maleDb = FirebaseDatabase.getInstance().getReference().child("Users").child("Male");
            maleDb.addChildEventListener(new ChildEventListener() {
                public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                    if (dataSnapshot.getKey().equals(user.getUid())) {
                       userSex = "Male";
                     oppositeUserSex = "Female";
                       getOppositeUser();
                    }
                }

                public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                }

                public void onChildRemoved(DataSnapshot dataSnapshot) {
                }

                public void onChildMoved(DataSnapshot dataSnapshot, String s) {
                }

                public void onCancelled(DatabaseError databaseError) {
                }
            });

            DatabaseReference femaleDb = FirebaseDatabase.getInstance().getReference().child("Users").child("Female");
           femaleDb.addChildEventListener(new ChildEventListener() {
                public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                    if (dataSnapshot.getKey().equals(user.getUid())) {
                      userSex = "Female";
                        oppositeUserSex = "Male";
                        getOppositeUser();
                    }
                }

                public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                }

                public void onChildRemoved(DataSnapshot dataSnapshot) {
                }

                public void onChildMoved(DataSnapshot dataSnapshot, String s) {
                }

                public void onCancelled(DatabaseError databaseError) {
                }
            });
        }



        public void getOppositeUser() {
            DatabaseReference oppositeSexDb= FirebaseDatabase.getInstance().getReference().child("Users").child(oppositeUserSex);
            FirebaseDatabase.getInstance().getReference().child("Users").child(this.oppositeUserSex).addChildEventListener(new ChildEventListener() {
                public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                   // if (dataSnapshot.exists()&& !dataSnapshot.child("connection").child("nope").hasChild(currentUid)&&!dataSnapshot.child("connection").child("yep").hasChild(currentUid)) {
                      //  cards item = new cards(dataSnapshot.getKey(),dataSnapshot.child("name").getValue().toString());
                       // rowItems.add(item);
                       // arrayAdapter.notifyDataSetChanged();
                       String str = "connection";
                        if (!dataSnapshot.child(str).child("nope").hasChild(MainActivity.this.currentUid) && !dataSnapshot.child(str).child("yep").hasChild(MainActivity.this.currentUid)) {
                          rowItems.add(new cards(dataSnapshot.getKey(), dataSnapshot.child("name").getValue().toString()));
                            arrayAdapter.notifyDataSetChanged();
                       // }
                    }
                }

                public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                }

                public void onChildRemoved(DataSnapshot dataSnapshot) {
                }

                public void onChildMoved(DataSnapshot dataSnapshot, String s) {
                }

                public void onCancelled(DatabaseError databaseError) {
                }
            });
        }






    public void signOut(View view) {
        mAuth.signOut();
        Intent i = new Intent(MainActivity.this,LoginActivity.class);
        startActivity(i);
        finish();
        return;
    }


    public void goToProfile(View view) {

        Intent i = new Intent(MainActivity.this,ProfileActivity.class);
        i.putExtra("userSex",userSex);

        startActivity(i);
    }
}