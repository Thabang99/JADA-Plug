package bw.ac.biust.datingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuth.AuthStateListener;
import com.google.firebase.database.FirebaseDatabase;

import static android.widget.Toast.LENGTH_SHORT;

public class RegisterActivity extends AppCompatActivity {

    private AuthStateListener firebaseAuthStateListener;
    private FirebaseAuth mAuth;

    private RadioGroup mRadioGroup;

    private Button mRegister;
    private EditText mRegisterPass,mConfirmPass,mRegisterName,mRealName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        mAuth = FirebaseAuth.getInstance();
        firebaseAuthStateListener = new AuthStateListener() {
            public void onAuthStateChanged(FirebaseAuth firebaseAuth) {
                if (FirebaseAuth.getInstance().getCurrentUser() != null) {
                    startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                }
            }
        };

        mRegister = (Button) findViewById(R.id.registerBtn);
        mRegisterPass = (EditText) findViewById(R.id.registerPass);
        mConfirmPass = (EditText) findViewById(R.id.confirmPass);
        mRadioGroup = (RadioGroup) findViewById(R.id.genderBtn);
        mRegisterName = (EditText) findViewById(R.id.registerName);
        mRealName = (EditText) findViewById(R.id.realName);
        mRegister.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                final RadioButton radioButton = (RadioButton) findViewById(RegisterActivity.this.mRadioGroup.getCheckedRadioButtonId());
                if (radioButton.getText() != null) {
                    String email = mRegisterName.getText().toString();
                    String password = mRegisterPass.getText().toString();
                    final String name = mRealName.getText().toString();

                    mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(RegisterActivity.this, new OnCompleteListener<AuthResult>() {
                        public void onComplete(Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                FirebaseDatabase.getInstance().getReference().child("Users").child(radioButton.getText().toString()).child(RegisterActivity.this.mAuth.getCurrentUser().getUid()).child("name").setValue(name);
                                return;
                            }
                            Toast.makeText(RegisterActivity.this, "ERROR SIGNING UP", LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });

    }

    /* Access modifiers changed, original: protected */
    public void onStart() {
        super.onStart();
        this.mAuth.addAuthStateListener(this.firebaseAuthStateListener);
    }

    /* Access modifiers changed, original: protected */
    public void onStop() {
        super.onStop();
        this.mAuth.removeAuthStateListener(this.firebaseAuthStateListener);
    }


    public void back(View view) {
        Intent intent = new Intent(RegisterActivity.this , LoginActivity.class);
        startActivity(intent);
    }
}